# Other

## profiling_decorator

[[autodoc]] extras.profiling.profiling_decorator

## profiling_context

[[autodoc]] extras.profiling.profiling_context
