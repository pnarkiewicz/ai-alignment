# Scripts Utilities

## ScriptArguments

[[autodoc]] ScriptArguments

## TrlParser

[[autodoc]] TrlParser
    - parse_args_and_config
    - parse_args_into_dataclasses
    - set_defaults_with_config
